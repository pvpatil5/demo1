var login = require("C:/Users/Pradeep/Desktop/demo_webdriverIO/test/pageobjects/loginPage.js")

describe('loging to application',  () => {
    it('login', async () => {
       await login.navigateTOUrl("http://www.testyou.in/Login.aspx")
       await login.entervalue(login.username, "pradeep")
       await login.entervalue(login.password, "1234")
       await login.clickOnElement(login.loginBtn)
       await login.validatingResultText()
    });
});

